import 'package:flutter/material.dart';
import 'tab_page_template.dart';

class PortfolioPage extends StatelessWidget {
  final List<Map<String, String>> projects = [
    {
      'Num': 'Project 01.',
      'title': 'Flutter로 작성된 프로젝트',
      'date': '2024-11-27',
      'contribution': '프로젝트 팀장',
      'language': 'HTML, CSS, JavaScript',
      'description': '테스트 1번 설명용',
      'picture': ('image/image2.jpg'),
    },
    {
      'Num': 'Project 02.',
      'title': 'React로 작성된 프로젝트',
      'date': '2023-10-15',
      'contribution': '프로젝트 팀장',
      'language': 'HTML, CSS, JavaScript',
      'description': '테스트 2번 설명용',
      'picture': 'image/image3.jpg',
    },
    {
      'Num' : 'Project 03.',
      'title': 'Python으로 작성된 데이터 분석',
      'date': '2022-05-09',
      'contribution': '프로젝트 팀장',
      'language': 'HTML, CSS, JavaScript',
      'description': '테스트 3번 설명용',
      'picture': 'image/image4.jpg',
    },
  ];
  @override
  Widget build(BuildContext context) {
    return TabPageTemplate(
      selectedIndex: 2,
      child: ListView.builder(
        padding: EdgeInsets.all(10),
        itemCount: projects.length, // 프로젝트 개수에 따라 동적 생성
        itemBuilder: (context, index) {
          final project = projects[index];
          return Card(
            margin: EdgeInsets.symmetric(vertical: 5.0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(5.0),
            ),
            child: ListTile(
              title: Text(
                project['Num']!, // 프로젝트 넘버링
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    project['title']!, // 프로젝트 제목
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                  SizedBox(height: 8.0),
                  Text(
                    "완료 날짜 : ${project['date']}",
                    style: TextStyle(fontSize: 14, color: Colors.grey),
                  ),
                  Text(
                    "기여도 : ${project['contribution']}",
                    style: TextStyle(fontSize: 14, color: Colors.grey),
                  ),
                  SizedBox(height: 8.0),
                  Text(
                    "[개발 언어]\n${project['language']}",
                    style: TextStyle(fontSize: 14, color: Colors.grey),
                  ),
                  SizedBox(height: 8.0),
                  Text(
                    "[프로젝트 개요]\n${project['description']}",
                    style: TextStyle(fontSize: 14, color: Colors.grey),
                  ),
                  SizedBox(height: 8.0),
                  Image.asset(project['picture']!),
                ],
              ),

            ),
          );
        },
      ),
    );
  }
}
