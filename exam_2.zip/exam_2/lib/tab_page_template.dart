import 'package:flutter/material.dart';

class TabPageTemplate extends StatefulWidget {
  final Widget child; // 각 페이지의 고유 콘텐츠
  final int selectedIndex; // 현재 페이지의 인덱스

  const TabPageTemplate({
    required this.child,
    required this.selectedIndex,
  });

  @override
  _TabPageTemplateState createState() => _TabPageTemplateState();
}

class _TabPageTemplateState extends State<TabPageTemplate>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    // TabController 초기화 및 현재 선택된 탭 설정
    _tabController = TabController(
      length: 3,
      vsync: this,
      initialIndex: widget.selectedIndex,
    );

    // 탭 변경 시 라우트 전환
    _tabController.addListener(() {
      if (_tabController.indexIsChanging) {
        switch (_tabController.index) {
          case 0:
            Navigator.pushReplacementNamed(context, '/resume');
            break;
          case 1:
            Navigator.pushReplacementNamed(context, '/introduce');
            break;
          case 2:
            Navigator.pushReplacementNamed(context, '/portfolio');
            break;
        }
      }
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("포트폴리오 페이지"),
        bottom: TabBar(
          controller: _tabController,
          tabs: [
            Tab(text: '이력서'),
            Tab(text: '자기소개서'),
            Tab(text: '포트폴리오'),
          ],
        ),
      ),
      body: widget.child,
    );
  }
}
