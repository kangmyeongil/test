import 'package:flutter/material.dart';
import 'package:exam_2/resume.dart';
import 'package:exam_2/introduce.dart';
import 'package:exam_2/portfolio.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: '/resume',
      routes: {
        '/resume': (context) => ResumePage(),
        '/introduce': (context) => IntroducePage(),
        '/portfolio': (context) => PortfolioPage(),
      },
    );
  }
}