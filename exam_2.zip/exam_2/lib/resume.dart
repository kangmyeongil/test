import 'package:flutter/material.dart';
import 'tab_page_template.dart';
import 'package:url_launcher/url_launcher.dart';

// 이력서 탭 위젯 정의
class ResumePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return TabPageTemplate(
      selectedIndex: 0,
      child: SingleChildScrollView( // 스크롤 가능 영역 추가
        child: Row( // 좌우로 나눠진 두 열 구성
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 왼쪽 영역: 배경색이 파란색이고, 연락처, 학력, 스킬 정보 포함
            Expanded(
              flex: 1, // 화면 너비의 1/3 차지
              child: Container(
                color: Colors.blue[900], // 배경색
                padding: EdgeInsets.all(16), // 내부 여백
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // 프로필 사진
                    Center(
                      child: CircleAvatar(
                        radius: 50,
                        backgroundImage: AssetImage('image/image.jpg'), // 이미지 파일
                      ),
                    ),
                    SizedBox(height: 20), // 간격
                    // CONTACT 섹션
                    SelectableText(
                      'CONTACT',
                      style: TextStyle(
                          color: Colors.white, fontSize: 10,
                          fontWeight: FontWeight.bold
                      ),
                    ),
                    SizedBox(height: 10),
                    // 연락처 정보 항목
                    ContactItem(icon: Icons.phone, text: '010-8871-9723'),
                    ContactItem(icon: Icons.email, text: 'blza2345@gmail.com'),
                    ContactItem(icon: Icons.web, text: 'https://github.com/kangmyeongil'),
                    SizedBox(height: 20),
                    // EDUCATION 섹션
                    SelectableText('EDUCATION',
                      style: TextStyle(
                          color: Colors.white, fontSize: 10,
                          fontWeight: FontWeight.bold
                      ),
                    ),
                    SizedBox(height: 10),
                    // 학력 정보 항목
                    EducationItem(
                        year: '2017-2020',
                        title: '브니엘고등학교', subtitle: ' '
                    ),
                    EducationItem(
                        year: '2020 - 현재',
                        title: '신라대학교', subtitle: '컴퓨터공학부'
                    ),
                    SizedBox(height: 10),
                    // SKILLS 섹션
                    SelectableText('SKILLS',
                      style: TextStyle(
                          color: Colors.white, fontSize: 10,
                          fontWeight: FontWeight.bold
                      ),
                    ),
                    SizedBox(height: 10),
                    // 스킬 목록
                    SkillItem(text: 'Web Design'),
                    SkillItem(text: 'DB Design'),
                    SkillItem(text: 'Spring Framework'),
                    SizedBox(height: 300), // 하단 여백
                  ],
                ),
              ),
            ),
            // 오른쪽 영역: 배경색이 회색이고, 프로필, 경력 내용 포함
            Expanded(
              flex: 2,
              child: Container(
                color: Colors.grey[200],
                padding: EdgeInsets.all(16),
                child: SelectableText.rich(
                  TextSpan(
                    children: [
                      // 이름
                      TextSpan(
                        text: 'KANG MYEONGIL\n',
                        style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.blue[900]),
                      ),
                      // 직업
                      TextSpan(
                        text: 'WEB DEVELOPER\n\n',
                        style: TextStyle(fontSize: 10, color: Colors.grey[700], letterSpacing: 2),
                      ),
                      // PROFILE
                      TextSpan(
                        text: 'PROFILE\n',
                        style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.blue[900]),
                      ),
                      TextSpan(
                        text: '웹 개발자를 목표로 하고 있는 강명일입니다. '
                            '개발자로서 더 많은 프로젝트에 참여하고 실용적이며 혁신적인 솔루션을 개발하는데 기여하고자 합니다. '
                            '저의 끊임없는 도전과 발전을 통해 조직의 일원으로서 성공적인 결과를 이루어내고 미래에는 보다 높은 목표를 향해 나아가기 위해 최선을 다하겠습니다.\n\n',
                        style: TextStyle(fontSize: 15, color: Colors.grey[800]),
                      ),
                      // EXPERIENCE
                      TextSpan(
                        text: 'EXPERIENCE\n',
                        style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.blue[900]),
                      ),
                      // ExperienceItem 활용
                      ExperienceItem(
                        title: '고객 서비스 경험',
                        period: '2022.03~',
                        company: '송해반점',
                        details: ['설거지', '서빙', '접객'],
                      ).toTextSpan(),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// 연락처 항목 위젯
class ContactItem extends StatelessWidget {
  final IconData icon; // 아이콘 데이터
  final String text; // 연락처 텍스트

  ContactItem({required this.icon, required this.text});

  void _launchURL(String url) async {
    final Uri uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else {
      throw 'Could not launch $url';
    }
  }

  @override
  Widget build(BuildContext context) {
    final bool isUrl = Uri.tryParse(text)?.hasAbsolutePath ?? false;

    return InkWell(
      onTap: isUrl ? () => _launchURL(text) : null, // URL일 때만 동작
      mouseCursor: isUrl ? SystemMouseCursors.click : SystemMouseCursors.basic, // URL일 때만 커서 변경
      child: LayoutBuilder(
        builder: (context, constraints) {
          if (constraints.maxWidth < 200) {
            return Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(icon, color: Colors.white), // 아이콘
                SizedBox(width: 10),
                Expanded(
                  child: SelectableText(
                    text,
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            );
          } else {
            return Row(
              children: [
                Icon(icon, color: Colors.white), // 아이콘
                SizedBox(width: 10),
                Flexible(
                  child: SelectableText(
                    text,
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            );
          }
        },
      ),
    );
  }
}

// 학력 항목 위젯
class EducationItem extends StatelessWidget {
  final String year; // 연도
  final String title; // 학교 이름
  final String subtitle; // 부가 설명

  EducationItem({
    required this.year,
    required this.title,
    required this.subtitle
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SelectableText(year, style: TextStyle(color: Colors.white, fontSize: 14)), // 연도 텍스트
        SelectableText(title, style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)), // 제목 텍스트
        SelectableText(subtitle, style: TextStyle(color: Colors.white)), // 부가 설명 텍스트
        SizedBox(height: 10), // 항목 간 간격
      ],
    );
  }
}

// 스킬 항목 위젯
class SkillItem extends StatelessWidget {
  final String text; // 스킬 이름

  SkillItem({required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: 5), // 아래 여백
      child: SelectableText('ㆍ $text',
          style: TextStyle(color: Colors.white) // 텍스트 스타일
      ),
    );
  }
}

// 경력 항목 위젯
class ExperienceItem{
  final String title; // 직무 이름
  final String period; // 근무 기간
  final String company; // 회사 이름
  final List<String> details; // 세부 사항 목록

  ExperienceItem({
    required this.title,
    required this.period,
    required this.company,
    required this.details,
  });

  TextSpan toTextSpan() {
    return TextSpan(
      children: [
        TextSpan(
          text: '$title\n',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        TextSpan(
          text: '$period | $company\n',
          style: TextStyle(fontSize: 14, color: Colors.grey[700]),
        ),
        ...details.map(
              (detail) => TextSpan(
            text: 'ㆍ $detail\n',
            style: TextStyle(fontSize: 14, color: Colors.grey[800]),
          ),
        ),
      ],
    );
  }
}