import 'package:flutter/material.dart';
import 'tab_page_template.dart';

// 새로운 Intro
class IntroducePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return TabPageTemplate(
      selectedIndex: 1,
      child: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 제목
              Text(
                "자기소개서",
                style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.blue[900]),
              ),
              SizedBox(height: 20),
              // 성장과정
              SectionTitle(title: "성장과정"),
              SizedBox(height: 10),
              Text(
                "고등학교 시절 친구의 권유로 학교에서 컴퓨터부에 속했습니다. 컴퓨터부에서 파이썬으로 그림을 그리는 "
                    "정도의 간단한 프로그래밍을 배웠는데, 제가 만든 코드가 혼자 움직이며 그림을 그리는 것이 신기했습니다. "
                    "이때부터 컴퓨터에 대한 관심이 생겨 신라대학교 컴퓨터소프트웨어공학과에 입학하게 되었습니다.\n\n"
                    "대학교 생활 중 2학년 때 수강한 자바 프로그래밍 강의는 저의 진로 결정을 위한 특별한 계기가 되었습니다. "
                    "보충 강의를 통해 과제를 무사히 마칠 수 있었고, 기말고사에서는 요구조건을 모두 작성하며 실력을 입증했습니다.",
                style: TextStyle(fontSize: 14, color: Colors.grey[800]),
              ),
              SizedBox(height: 20),
              // 성격의 장단점
              SectionTitle(title: "성격의 장단점"),
              SizedBox(height: 10),
              Text(
                "저의 장점 중 하나는 성실함입니다. 저는 22년 4월부터 현재까지 매주 중국집에서 홀서빙 아르바이트를 하고 있습니다. "
                    "손님을 여유롭게 맞이할 수 있도록 출근시간보다 일찍 가게에 도착하여 영업 준비를 마치고, 별다른 지시가 없어도 "
                    "자발적으로 일을 하고 있습니다.\n\n"
                    "또 다른 장점으로는 좋아하는 부분에 깊은 관심을 가지고 꾸준히 노력하는 성향입니다. "
                    "초등학교 6학년 때 한자에 대한 관심을 갖고 기출 문제를 수없이 풀고 한자를 외우며 한자능력검정시험 1급을 따냈습니다. "
                    "자바 프로그래밍과 데이터베이스에 대한 흥미를 갖고 꾸준한 노력을 통해 높은 학점을 획득하였습니다.\n\n"
                    "하지만 결정을 내릴 때 시간이 조금 더 걸리는 경향이 있습니다. 이러한 단점을 극복하기 위해 우선순위를 정하여 "
                    "작은 규모의 결정부터 시작하는 노력을 하고 있습니다.",
                style: TextStyle(fontSize: 14, color: Colors.grey[800]),
              ),
              SizedBox(height: 20),
              // 전문지식
              SectionTitle(title: "전문지식"),
              SizedBox(height: 10),
              Text(
                "대학교 전공 수업에서 데이터베이스의 핵심 개념과 용어를 체계적으로 학습하였습니다. 테이블, 열, 행의 관계를 명확히 이해하고, "
                    "이를 효과적으로 활용하여 데이터를 구조화하는 방법을 배웠습니다. 특히 정규화를 통해 데이터 중복을 최소화하고 데이터 일관성을 "
                    "확보하는 프로세스를 익혔습니다.\n\n"
                    "SQL 쿼리를 작성하며 간단한 데이터 조회부터 INSERT, UPDATE, DELETE 등의 다양한 작업을 수행할 수 있으며, "
                    "JOIN 절을 활용하여 복잡한 데이터 검색과 조작도 가능합니다. ERD(Entity-Relationship Diagram)를 작성하여 비즈니스 "
                    "요구사항을 분석하고 효율적인 데이터베이스 스키마를 설계한 경험이 있습니다.",
                style: TextStyle(fontSize: 14, color: Colors.grey[800]),
              ),
              SizedBox(height: 20),
              // 향후 포부
              SectionTitle(title: "향후 포부"),
              SizedBox(height: 10),
              Text(
                "소프트웨어 개발자로서 더 많은 프로젝트에 참여하고 실용적이며 혁신적인 솔루션을 개발하는 데 기여하고자 합니다. "
                    "특히 데이터베이스 분야에서의 전문성을 더욱 키워 데이터 관리와 분석에 기여할 수 있는 역할을 수행하고자 합니다.\n\n"
                    "동료들과 협업하며 서로의 역량을 높이고, 끊임없는 도전과 발전을 통해 조직의 일원으로서 성공적인 결과를 이루어내겠습니다.",
                style: TextStyle(fontSize: 14, color: Colors.grey[800]),
              ),
            ],
          ),
        ),
      )
    );
  }
}

// 섹션 제목을 스타일링하는 위젯
class SectionTitle extends StatelessWidget {
  final String title;

  SectionTitle({required this.title});

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.bold,
        color: Colors.blue[900],
      ),
    );
  }
}

